#2023/12/20
#@ Meiqian Chen

library(readr)
library(RColorBrewer)
library(reshape2)
library(ggplot2)
library(ggprism)
library(tidyverse)
library(ggsci)
library(ggalluvial)

load('sdgs_data.Rdata')

#plot figure2
col=c(rgb(037,043,128,max=255),rgb(055,028,164,max=255),rgb(125,019,021,max=255),rgb(060,109,180,max=255),rgb(072,198,235,max=255),rgb(129,201,152,max=255),rgb(189,214,056,max=255),
      rgb(251,205,017,max=255),rgb(239,094,033,max=255))

mytheme=theme(
  axis.line.y=element_line(linewidth=0.5),
  axis.line.x=element_line(linewidth=0.5),
  axis.ticks.x=element_line(linewidth=0.5),
  axis.ticks.y=element_line(linewidth=0.5),
  panel.grid.major.y=element_blank(),
  panel.grid.major.x=element_blank(),
  axis.text.x = element_text(size = 10,color='black'),
  axis.text.y = element_text(size = 10,color='black'),
  axis.title.y=element_text(size=11,color='black'),
  plot.title = element_text(size = 10,face="bold",hjust = 0.5),
  plot.margin=unit(c(0.2,0.1,0,0.1), 'lines'),
  text=element_text("Helvetica")
)


#Announced Pledges
p1=ggplot(dat_plot[[1]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='SDG scores',title = 'Announced Pledges',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p1


#Below 2°C
p2=ggplot(dat_plot[[2]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='',title = 'Below 2°C',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p2

#Carbon Neutrality
p3=ggplot(dat_plot[[3]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='',title = 'Carbon Neutrality',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p3

#Carbon Neutrality
p4=ggplot(dat_plot[[4]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='SDG scores',title = 'Carbon Neutral Scenario 2',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p4


#NET-led
p5=ggplot(dat_plot[[5]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='',title = 'NET-led ',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p5


#PEAK30
p6=ggplot(dat_plot[[6]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='',title = 'PEAK30 ',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p6


#RE-led
p7=ggplot(dat_plot[[7]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='SDG scores',title = 'RE-led ',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p7



#Updated NDC to Carbon Neutrality
p8=ggplot(dat_plot[[8]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,182)+
  labs(x='',y='',title = 'Updated NDC to Carbon Neutrality ',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p8


#1.5°C
p9=ggplot(dat_plot[[9]], aes( x = year,y=score,fill = group,stratum = group, alluvium = group))+
  geom_stratum(width = 0.5, color='white')+
  geom_alluvium(alpha = 0.5,
                width = 0.5,
                curve_type = "linear")+
  scale_fill_manual(values=col)+
  ylim(-40,180)+
  labs(x='',y='',title = '1.5°C',fill='')+
  theme_classic()+
  mytheme+
  scale_x_discrete(expand = c(0.2,0.2))
p9


grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, 
                                       position = c("bottom", "right")) {
  require(gridExtra)
  require(grid)
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "bottom" = arrangeGrob(do.call(arrangeGrob, gl),
                                            legend,
                                            ncol = 1,
                                            heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "right" = arrangeGrob(do.call(arrangeGrob, gl),
                                           legend,
                                           ncol = 2,
                                           widths = unit.c(unit(1, "npc") - lwidth, lwidth)))
  grid.newpage()
  grid.draw(combined)
  # return gtable invisibly
  invisible(combined)
}

grid_arrange_shared_legend(p1, p2,p3,p4,p5,p6,p7,p8,p9,ncol = 3,nrow = 3, position='bottom')
