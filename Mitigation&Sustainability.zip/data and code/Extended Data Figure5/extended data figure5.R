#2023/12/20
#@Meiqian Chen

load('CO2_data.Rdata')
load('cost_data.Rdata')

#CO2
Name=c('Best CMP in mitigation cost','Best CMP in carbon reduction','Most cost-effective CMP','Reference','Announced Pledges','Below 2°C','Carbon Neutrality','Carbon Neutral Scenario 2','NET-led','PEAK30','RE-led','Updated NDC to Carbon Neutrality','1.5°C')
mytheme=theme(
  axis.ticks=element_line(linewidth=0.6),
  axis.line=element_blank(),
  panel.grid.major=element_line(linewidth=0.3),
  panel.grid.minor = element_blank(),
  panel.border = element_rect(fill=NA,color='black',size=1),
  axis.text.y =element_text(size=10,color='black'),
  axis.text.x =element_text(size=10,color='black',margin = margin(b=2)),
  axis.title.y=element_text(size=14,color='black',hjust = 0.5),
  plot.margin=unit(c(0,-1,0,0), 'cm'),
  text=element_text("Helvetica")
)
library(RColorBrewer)
gre=brewer.pal(9,"Greys")
palette=c('#50c48f','#3685fe','#f5616f','black',brewer.pal(12,"Paired")[c(1:5,8:10,12)])
names(palette)=Name
fig1=ggplot()+
  geom_ribbon(data=range_CO2,aes(x=year,ymin = min, ymax = max),fill=gre[4],alpha=0.6) +
  geom_line(data=CO2_plot_2,aes(x=year,y=score,group=index,color=group,linetype=group),linewidth=1.1) +
  geom_point(data=CO2_plot_2,aes(x=year,y=score,group=index,color=group,shape=group),size=2.5,stroke=0.9) +
  ylim(-5,17)+
  scale_colour_manual(name=element_blank(),values=palette,breaks=Name,labels=c(Name))+
  scale_linetype_manual(name=element_blank(),values=c('solid','solid','solid','solid',rep('dotdash',9)),breaks=Name,labels=Name)+
  scale_shape_manual(name=element_blank(),values=c(rep(1,4),rep(NA,9)),breaks=Name,labels=Name)+
  labs(x='',y=expression(paste(bold('GtCO'['2']))),title = '')+
  theme_bw()+
  mytheme+
  theme(legend.position='none')+
  scale_x_continuous(breaks = seq(2030,2060,5),expand = c(0.03,0.03))
fig1

mytheme_box=theme(
  axis.ticks=element_line(linewidth=0.6),
  axis.line=element_blank(),
  panel.grid.major=element_line(linewidth=0.3),
  panel.grid.minor = element_blank(),
  panel.border = element_rect(fill=NA,color='black',size=1),
  axis.text.y =element_text(size=12,vjust=0.7,color='black'),
  axis.text.x =element_text(size=10,vjust=0.7,angle=45,color='black',margin = margin(b=2)),
  axis.title.y=element_text(size=15,color='black',hjust = 0.5),
  plot.margin=unit(c(0,-1,0,0), 'cm'),
  text=element_text("Helvetica")
)
fig1_box=ggplot(data=CO2_plot_1_1,aes(x=year,y=score,fill=year))+
  stat_boxplot(geom='errorbar',width=0.5)+
  geom_boxplot()+
  ylim(-5,17)+
  scale_fill_manual(values=c('#26ccd8', '#9977ef', '#f7b13f','#f9e264'))+
  labs(x='',y='',title = '')+
  theme_bw()+
  mytheme_box+
  theme(axis.ticks.y=element_blank(),axis.text.y =element_blank(),axis.title.y=element_blank(),plot.margin=unit(c(0,0,0,-1), 'cm'))+
  theme(legend.position="none")
fig1_box

p1=fig1+plot_spacer()+fig1_box+plot_layout(widths = c(4,-0.08,0.8),guides = "collect")+plot_annotation(
  title = expression(paste(bold('CO'['2']),sep=' ',bold('emissions'))),
  theme = theme(plot.title = element_text(size = 16,hjust = 0.5,vjust = -6,face="bold"))
)
p1


#cost
Name=c('Best CMP in mitigation cost','Best CMP in carbon reduction','Most cost-effective CMP','Reference','Announced Pledges','Below 2°C','Carbon Neutrality','Carbon Neutral Scenario 2','NET-led','PEAK30','RE-led','Updated NDC to Carbon Neutrality','1.5°C')
mytheme=theme(
  axis.ticks=element_line(linewidth=0.6),
  axis.line=element_blank(),
  panel.grid.major=element_line(linewidth=0.3),
  panel.grid.minor = element_blank(),
  panel.border = element_rect(fill=NA,color='black',size=1),
  axis.text.y =element_text(size=10,color='black'),
  axis.text.x =element_text(size=10,color='black',margin = margin(b=2)),
  axis.title.y=element_text(size=14,color='black',hjust = 0.5),
  plot.margin=unit(c(0,-1,0,0), 'cm'),
  text=element_text("Helvetica")
)
library(RColorBrewer)
gre=brewer.pal(9,"Greys")
palette=c('#50c48f','#3685fe','#f5616f','black',brewer.pal(12,"Paired")[c(1:5,8:10,12)])
names(palette)=Name
fig2=ggplot()+
  geom_ribbon(data=range_cost,aes(x=year,ymin = min, ymax = max),fill=gre[4],alpha=0.6) +
  geom_line(data=cost_plot_2,aes(x=year,y=score,group=index,color=group,linetype=group),linewidth=1.1) +
  geom_point(data=cost_plot_2,aes(x=year,y=score,group=index,color=group,shape=group),size=2.5,stroke=0.9) +
  ylim(0,2.2)+
  scale_colour_manual(name=element_blank(),values=palette,breaks=Name,labels=c(Name))+
  scale_linetype_manual(name=element_blank(),values=c('solid','solid','solid','solid',rep('dotdash',9)),breaks=Name,labels=Name)+
  scale_shape_manual(name=element_blank(),values=c(rep(1,4),rep(NA,9)),breaks=Name,labels=Name)+
  labs(x='',y=expression(paste(bold('Trillion USD$'~ yr^{-1}))),title = '')+
  theme_bw()+
  mytheme+
  theme(legend.position='none')+
  scale_x_continuous(breaks = seq(2030,2060,5),expand = c(0.03,0.03))
fig2

mytheme_box=theme(
  axis.ticks=element_line(linewidth=0.6),
  axis.line=element_blank(),
  panel.grid.major=element_line(linewidth=0.3),
  panel.grid.minor = element_blank(),
  panel.border = element_rect(fill=NA,color='black',size=1),
  axis.text.y =element_text(size=12,vjust=0.7,color='black'),
  axis.text.x =element_text(size=10,vjust=0.7,angle=45,color='black',margin = margin(b=2)),
  axis.title.y=element_text(size=15,color='black',hjust = 0.5),
  plot.margin=unit(c(0,-1,0,0), 'cm'),
  text=element_text("Helvetica")
)
fig2_box=ggplot(data=cost_plot_1_1,aes(x=year,y=score,fill=year))+
  stat_boxplot(geom='errorbar',width=0.5)+
  geom_boxplot()+
  ylim(0,2.2)+
  scale_fill_manual(values=c('#26ccd8', '#9977ef', '#f7b13f','#f9e264'))+
  labs(x='',y='',title = '')+
  theme_bw()+
  mytheme_box+
  theme(axis.ticks.y=element_blank(),axis.text.y =element_blank(),axis.title.y=element_blank(),plot.margin=unit(c(0,0,0,-1), 'cm'))+
  theme(legend.position="none")
fig2_box

p2=fig2+plot_spacer()+fig2_box+plot_layout(widths = c(4,-0.08,0.8),guides = "collect")+plot_annotation(
  title = 'Mitigation cost',
  # caption = 'made with patchwork',
  theme = theme(plot.title = element_text(size = 16,hjust = 0.5,vjust = -6,face="bold"))
)
p2 


