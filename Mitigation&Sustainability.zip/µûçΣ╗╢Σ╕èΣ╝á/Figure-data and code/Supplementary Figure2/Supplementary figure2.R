#2024/6/3
#@Meiqian Chen

load('Reference_data.Rdata')

library(RColorBrewer)
library(png)
library(grid)
library(ggimage)
library(patchwork)
palatte=brewer.pal(9,"Greys")
lab_colors=c(palatte[8],'#E6253B','#DDA839','#4D9F37','#C51A2D','#FF3A21','#26BEE2','#FCC40B',
             '#A11942','#FD6A25','#DD1467','#FC9E25','#BF8C2E','#3F7E44','#0A97D9',
             '#55BF2D','#01699C','#18496A')
name=c('Overall','SDG1','SDG2','SDG3','SDG4','SDG5','SDG6','SDG7','SDG8','SDG9','SDG10','SDG11','SDG12','SDG13','SDG14','SDG15','SDG16','SDG17')
names(lab_colors)=name



##2022
list_2022=c(0,NA,19)
plot_2022=rbind(dat_2022,list_2022)
number_of_bar =nrow(plot_2022)
angle <- 90 - 360 * (plot_2022$id-0.5) /number_of_bar 
plot_2022$hjust <- ifelse( angle < -90, 1, 0)
plot_2022$angle <- ifelse(angle < -90, angle+180, angle)
plot_2022$angle1 <- plot_2022$angle -90
num_22=round(plot_2022$score,2)[1:18]

mytheme=  theme( 
  axis.text = element_blank(),
  axis.title = element_blank(), 
  panel.grid = element_blank(),
  plot.title = element_text(hjust = 0.5,vjust = -2, size = 15,face="bold"),
  text=element_text("Helvetica")
)
p1 <-
  ggplot(plot_2022)+ 
  geom_bar(aes(x=as.factor(id), y=c(rep(110,18),0)), stat="identity", fill=NA,
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y=c(rep(100,18),0)), stat="identity", 
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y= score , fill=group), stat="identity",
           alpha=0.8) +
 geom_blank(aes(y = -40)) + 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(25,25)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(50,50)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(75,75)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  ggplot2::annotate("text", x = rep(max(plot_2022$id),5), y = c(0, 25, 50, 75, 100), label = c("0", '25',"50",'75', "100") , color=palatte[9], size=4 , angle=0, fontface="bold", hjust=0.5) +
  geom_text(data=plot_2022, aes(x=id, y=100, label=c(name,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=3.5, fontface="bold",angle= plot_2022$angle, inherit.aes = FALSE ) +
  geom_text(data=plot_2022, aes(x=id-0.32, y=score+6, label=c(num_22,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=2.5,fontface="bold",angle= plot_2022$angle1, inherit.aes = FALSE ) +
  labs(title='2022')+
  theme_minimal() +
  mytheme+
  theme(legend.position='none')+
  coord_polar(theta = "x", start = 0, direction=1) +
  scale_fill_manual(values = lab_colors)
p1


##2030
list_2030=c(0,0,0,NA,NA,19)
plot_2030=rbind(dat_2030,list_2030)
number_of_bar =nrow(plot_2030)
angle <- 90 - 360 * (plot_2030$id-0.5) /number_of_bar 
plot_2030$hjust <- ifelse( angle < -90, 1, 0)
plot_2030$angle <- ifelse(angle < -90, angle+180, angle)
plot_2030$angle1 <- plot_2030$angle -90

mytheme=  theme(
  axis.text = element_blank(),
  axis.title = element_blank(), 
  panel.grid = element_blank(), 
  plot.title = element_text(hjust = 0.5,vjust = -2, size = 15,face="bold"),
  text=element_text("Helvetica")
)
num=round(plot_2030$Reference,2)[1:18]
p2 <-
  ggplot(plot_2030)+ 
  geom_bar(aes(x=as.factor(id), y=c(rep(110,18),0)), stat="identity", fill=NA,
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y=c(rep(100,18),0)), stat="identity", 
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y= Reference , fill=group), stat="identity",
           alpha=0.8) +
  geom_blank(aes(y = -40)) + 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(25,25)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(50,50)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(75,75)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  ggplot2::annotate("text", x = rep(max(plot_2022$id),5), y = c(0, 25, 50, 75, 100), label = c("0", '25',"50",'75', "100") , color=palatte[9], size=4 , angle=0, fontface="bold", hjust=0.5) +
  geom_text(data=plot_2030, aes(x=id, y=100, label=c(name,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=3.5, fontface="bold",angle= plot_2030$angle, inherit.aes = FALSE ) +
  geom_text(data=plot_2030, aes(x=id-0.32, y=Reference+6, label=c(num,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=2.5,fontface="bold",angle= plot_2030$angle1, inherit.aes = FALSE ) +
  labs(title='2030')+
  theme_minimal() +
  mytheme+
  theme(legend.position='none')+
  coord_polar(theta = "x", start = 0, direction=1) +
  scale_fill_manual(values = lab_colors)
p2


##2060
list_2060=c(0,0,0,NA,NA,19)
plot_2060=rbind(dat_2060,list_2060)
number_of_bar =nrow(plot_2060)
angle <- 90 - 360 * (plot_2060$id-0.5) /number_of_bar 
plot_2060$hjust <- ifelse( angle < -90, 1, 0)
plot_2060$angle <- ifelse(angle < -90, angle+180, angle)
plot_2060$angle1 <-  plot_2060$angle -90

mytheme=  theme(
  axis.text = element_blank(),
  axis.title = element_blank(), 
  panel.grid = element_blank(),
  plot.title = element_text(hjust = 0.5,vjust = -2, size = 15,face="bold"),
  text=element_text("Helvetica")
)
num_2060=round(plot_2060$Reference,2)[1:18]
p3 <-
  ggplot(plot_2060)+ 
  geom_bar(aes(x=as.factor(id), y=c(rep(110,18),0)), stat="identity", fill=NA,
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y=c(rep(100,18),0)), stat="identity", 
           alpha=0.2)  + 
  geom_bar(aes(x=as.factor(id), y= Reference , fill=group), stat="identity",
           alpha=0.8) +
  geom_blank(aes(y = -40)) + 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(25,25)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(50,50)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  geom_line(data=data.frame(x=c(-Inf,Inf),y=c(75,75)),aes(x=x,y=y),linetype='longdash',linewidth=0.5,color=palatte[5], alpha=0.5)+ 
  ggplot2::annotate("text", x = rep(max(plot_2022$id),5), y = c(0, 25, 50, 75, 100), label = c("0", '25',"50",'75', "100") , color=palatte[9], size=4 , angle=0, fontface="bold", hjust=0.5) +
  geom_text(data=plot_2060, aes(x=id, y=100+6, label=c(name,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=3.5, fontface="bold",angle= plot_2060$angle, inherit.aes = FALSE ) +
  geom_text(data=plot_2060, aes(x=id-0.32, y=Reference+6, label=c(num_2060,NA), hjust=hjust), color=c(lab_colors,NA),alpha=1, size=2.5, fontface="bold",angle= plot_2060$angle1, inherit.aes = FALSE ) +
  labs(title='2060')+
  theme_minimal() +
  mytheme+
  theme(legend.position='none')+
  coord_polar(theta = "x", start = 0, direction=1) +
  scale_fill_manual(values = lab_colors)
p3
