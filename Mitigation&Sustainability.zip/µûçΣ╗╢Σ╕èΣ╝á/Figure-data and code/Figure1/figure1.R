#2024.6.3
#@ Meiqian Chen

library(readr)
library(RColorBrewer)
library(reshape2)
library(ggplot2)
library(tidyverse)
library(magrittr)
library(GGally)
library(patchwork)
library(cowplot)
library(ggprism)

load('overall_data.Rdata')

name=c('Announced Pledges',
       'Below 2°C',
       'Carbon Neutrality',
       'Carbon Neutral Scenario 2',
       'NET-led',
       'PEAK30',
       'RE-led',
       'Updated NDC to Carbon Neutrality',
       '1.5°C','Average')
index=c('Energy efficiency','Energy mix','Negative emissions')
for (i in 1:2){
  colnames(plot[[i]])=c('score','CMP','group')
  plot[[i]]$CMP=rep(name,3)
  plot[[i]]$group=rep(index,each=10)
  plot[[i]]$CMP=factor(plot[[i]]$CMP,levels = (name))
}



#2030
mytheme_2030=theme(
  axis.line.y=element_line(linewidth=0.5),
  axis.line.x=element_blank(),
  axis.ticks.x=element_blank(),
  axis.ticks.y=element_line(linewidth=0.5),
  panel.grid.major.y=element_blank(),
  panel.grid.major.x=element_blank(),
  axis.text.y =element_text(size=12),
  axis.text.x =element_blank(),
  axis.title=element_text(size=11,color='black',hjust = 0.5),
  plot.margin=unit(c(0.5,1.5,0,0.5), 'cm'),
  plot.title=element_text(hjust=0.5,vjust=-1,size=18),
  text=element_text("Helvetica")
)
p1=ggplot(plot[[1]],aes(x=as.factor(CMP),y=score,fill=group,stratum = group, alluvium = group))+
  geom_col(position ="stack",width = 0.7)+
  geom_stripped_cols()+
  scale_fill_manual(values=c(rgb(055,082,164,max=255),rgb(129,201,152,max=255),rgb(251,205,017,max=255)),labels=c('Energy efficiency','Energy mix','Negative emissions'))+
  theme_prism()+
  labs(x='',y='Changes in overall SDG score',title = '2030')+
  mytheme_2030+
  theme(legend.position='non')


#2060
mytheme_2060=theme(
  axis.line.y=element_line(linewidth=0.5),
  axis.line.x=element_line(linewidth=0.5),
  axis.ticks.x=element_line(linewidth=0.5),
  axis.ticks.y=element_line(linewidth=0.5),
  panel.grid.major.y=element_blank(),
  panel.grid.major.x=element_blank(),
  axis.text.y =element_text(size=12),
  axis.text.x =element_text(size=10,color='black',margin = margin(b=6), angle = 340,vjust=1,hjust = 0),
  axis.title=element_text(size=11,color='black',hjust = 0.5),
  plot.margin=unit(c(0,1.5,0,0.5), 'cm'),
  plot.title=element_text(hjust=0.5,vjust=-1,size=18),
  text=element_text("Helvetica")
)
p2=ggplot(plot[[2]],aes(x=as.factor(CMP),y=score,fill=group,stratum = group, alluvium = group))+
  geom_col(position ="stack",width = 0.7)+
  geom_stripped_cols()+
  scale_fill_manual(values=c(rgb(055,082,164,max=255),rgb(129,201,152,max=255),rgb(251,205,017,max=255)),labels=c('Energy efficiency','Energy mix','Negative emission'))+
  theme_prism()+
  labs(x='',y='Changes in overall SDG score',title = '2060')+
  mytheme_2060+
  theme(legend.position=c(0.5,-0.4),legend.key.size = unit(12, "pt"),legend.text = element_text(size=12))+theme(legend.title = element_blank(),legend.direction = 'horizontal')

#plot figure1
figure1=(p1/plot_spacer()/p2)+plot_layout(heights = c(1,-0.18,1.08))
figure1
