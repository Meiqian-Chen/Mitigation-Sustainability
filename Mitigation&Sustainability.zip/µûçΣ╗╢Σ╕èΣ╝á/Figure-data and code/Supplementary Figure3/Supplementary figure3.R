#2023/12/20
#@ Meiqian Chen

load('sdgs_data_plot.Rdata')

#2030
mytheme=theme(
  axis.ticks.y=element_blank(),
  axis.line.y=element_line(linewidth=0.5),
  axis.line.x=element_line(linewidth=0.5),
  axis.ticks.x=element_line(linewidth=0.5),
  panel.grid.major.y=element_blank(),
  panel.grid.major.x=element_blank(),
  axis.text=element_text(size=10,color = 'black'),
  axis.text.y =element_text(margin = margin(r=0)),
  axis.text.x =element_text(size=10,color='black',margin = margin(b=6)),
  axis.title=element_text(size=11,color='black',hjust = 0.5),
  plot.margin=unit(c(0,0,0,0), 'lines'),
  text=element_text("Helvetica")
)
data_2030_plot_17=data_2030_plot[-c(1,16,31),]
p1=ggplot(data_2030_plot_17,aes(x=as.factor(cut),y=mean,fill=group))+
  geom_bar(stat = 'identity',position = position_dodge(0.8),width=0.8)+
  geom_errorbar(aes(ymin=min,ymax=max),position = position_dodge(0.8),width=0.5,size=0.5)+
  geom_hline(aes(yintercept=0),linetype='dashed',color='black')+
  geom_stripped_cols()+
  scale_fill_manual(values=c(rgb(055,082,164,max=255),rgb(129,201,152,max=255),rgb(251,205,017,max=255)),labels=c('Energy efficiency','Energy mix','Negative emissions'))+
  theme_prism()+
  labs(x='Individual SDGs',y='',title = '2030')+
  mytheme+
  theme(legend.position=c(0.72,0.95),legend.key.size = unit(12, "pt"),legend.text = element_text(size=12))+theme(legend.title = element_blank())+
  coord_flip()
p1



#2060
mytheme=theme(
  axis.ticks.y=element_blank(),
  axis.line.y=element_blank(),
  axis.line.x=element_line(linewidth=0.5),
  axis.ticks.x=element_line(linewidth=0.5),
  panel.grid.major.y=element_blank(),
  panel.grid.major.x=element_blank(),
  axis.text=element_text(size=10,color = 'black'),
  axis.text.y =element_blank(),
  axis.text.x =element_text(size=10,color='black',margin = margin(b=6)),
  axis.title=element_text(size=11,color='black',hjust = 0.5),
  plot.margin=unit(c(0,0,0,0), 'lines'),
  text=element_text("Helvetica")
)
data_2060_plot_17=data_2060_plot[-c(1,16,31),]
p2=ggplot(data_2060_plot_17,aes(x=as.factor(cut),y=mean,fill=group))+
  geom_bar(stat = 'identity',position = position_dodge(0.8),width=0.8)+
  geom_errorbar(aes(ymin=min,ymax=max),position = position_dodge(0.8),width=0.5,size=0.5)+
  geom_hline(aes(yintercept=0),linetype='dashed',color='black')+
  geom_stripped_cols()+
  scale_fill_manual(values=c(rgb(055,082,164,max=255),rgb(129,201,152,max=255),rgb(251,205,017,max=255)),labels=c('Energy efficiency','Energy mix','Negative emission'))+
  theme_prism()+
  labs(x='',y='',title = '2060')+
  mytheme+
  theme(legend.position='non')+
  coord_flip()
p2


plot=p1+p2
plot
