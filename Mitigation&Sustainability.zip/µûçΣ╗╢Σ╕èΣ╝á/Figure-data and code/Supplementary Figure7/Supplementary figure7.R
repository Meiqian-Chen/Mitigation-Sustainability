#2024/6/3
#@Meiqian Chen

library(readr)
library(RColorBrewer)
library(reshape2)
library(ggplot2)

load('Uncertainty_overall.Rdata')

palette<-c(brewer.pal(8,"Set2"))
mytheme <- theme(panel.grid.minor = element_blank(), axis.line = element_line(color='black',size=0.3),
                 strip.text = element_text(size=7),
                 plot.title = element_text(hjust = 0.5, size = 10,face='bold'),
                 axis.text.x = element_text(size = 6,color='black'),
                 axis.text.y = element_text(size = 6,color='black'),
                 axis.title.x=element_text(size=7),
                 axis.title.y=element_text(size=7),
                 plot.margin=unit(c(0.2,0.2,0,0.2), 'lines'))

grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, 
                                       position = c("bottom", "right")) {
  require(gridExtra)
  require(grid)
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "bottom" = arrangeGrob(do.call(arrangeGrob, gl),
                                            legend,
                                            ncol = 1,
                                            heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "right" = arrangeGrob(do.call(arrangeGrob, gl),
                                           legend,
                                           ncol = 2,
                                           widths = unit.c(unit(1, "npc") - lwidth, lwidth)))
  grid.newpage()
  grid.draw(combined)
  # return gtable invisibly
  invisible(combined)
}


#Announced Pledges
fig1=ggplot(IEA_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Announced Pledges",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



#Below 2°C
fig2=ggplot(CNREC_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Below 2°C",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



#Carbon Neutrality
fig3=ggplot(GEIDCO_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Carbon Neutrality",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



#Carbon Neutral Scenario 2
fig4=ggplot(ERI_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Carbon Neutral Scenario 2",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



#NET-led
fig5=ggplot(NET_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "NET-led",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))




#PEAK30
fig6=ggplot(PEAK30_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "PEAK30",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))





#RE-led
fig7=ggplot(RE_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "RE-led",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))




#Updated NDC to Carbon Neutrality
fig8=ggplot(EFC_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Updated NDC to Carbon Neutrality",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))




#1.5°C
fig9=ggplot(Tsinghua_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "1.5°C ",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



#cost-effective
fig10=ggplot(effective_data,aes(x=year))+
  geom_ribbon(aes(ymin = min, ymax = max,fill="100%"),alpha = 0.8) +
  geom_ribbon(aes(ymin = X0.25, ymax = X0.75,fill='50%'), alpha = 0.8) +
  geom_line(aes(y = Average,color=''),size=0.3)+
  scale_colour_manual(values='black') +
  scale_fill_manual(values =c("#66C2A5","#FFD92F"))+
  facet_wrap(~tssp, ncol = 5) +
  labs(x= "", y = "Overall SDG score", title = "Cost-effective",fill='Confidence bounds',color='Average value')+
  scale_x_continuous(breaks=seq(2030,2050,20))+
  mytheme+
  guides(fill=guide_legend(title.theme = element_text(size=10)))+
  guides(color=guide_legend(title.theme = element_text(size=10)))+
  theme(legend.position='bottom',legend.background = element_blank(),
        legend.box.margin = margin(0, 0, 0, 0),legend.key.size = unit(14, "pt"),legend.text = element_text(size=12))



grid_arrange_shared_legend(fig1,fig2,fig3,fig4, fig5,fig6,fig7,fig8,fig9,fig10,ncol = 2,nrow = 5, position='bottom')




